# Dinalibrium $DLI

> **Dynamic Equilibrium Asset Analyzer** — A universal signal tool for crypto, stocks, and any tradable asset.

[![License: MIT](https://img.shields.io/badge/License-MIT-teal.svg)](LICENSE)
[![GitHub Pages](https://img.shields.io/badge/Live-GitHub%20Pages-1dd5a0)](https://YOUR_USERNAME.github.io/dinalibrium)

---

## What is Dinalibrium?

Dinalibrium uses **Dynamic Equilibrium** — a principle from chemistry and physics — to analyze whether any asset is balanced, overextended, or undervalued. The core output is the **DES Score (Dinalibrium Equilibrium Score)**: a single number from 0–100 representing an asset's distance from its natural equilibrium point.

**DES Zones:**
| Score | Zone | Signal |
|-------|------|--------|
| 0–20 | Extreme Oversold | Strong boost needed |
| 20–42 | Under-Equilibrium | Accumulation zone |
| **42–58** | **Dinalibrium** | **Natural balance** |
| 58–80 | Over-Equilibrium | Distribution zone |
| 80–100 | Extreme Overbought | Reduce exposure |

---

## Quick Start

### Option A: Use the live app
Visit: `https://YOUR_USERNAME.github.io/dinalibrium`

### Option B: Run locally (Termux / Ubuntu / any terminal)

```bash
# 1. Clone
git clone https://github.com/YOUR_USERNAME/dinalibrium.git
cd dinalibrium

# 2. Run setup (handles Termux + Ubuntu)
bash scripts/setup_termux.sh

# 3. Start server
cd src
python3 -m http.server 8080

# 4. Open browser
# http://localhost:8080
```

### Option C: Just open the file
Open `src/index.html` directly in any browser. No build step needed.

---

## Run Tests

Open `tests/test_des_engine.html` in your browser.

All 17 tests should show **PASS** in green. If any fail, the engine logic has an error.

---

## Project Structure

```
dinalibrium/
├── src/
│   └── index.html          # Main app (single file, no build needed)
├── tests/
│   └── test_des_engine.html # DES engine test suite
├── docs/
│   └── WHITEPAPER.md       # $DLI Whitepaper v1.0
├── scripts/
│   └── setup_termux.sh     # Setup for Termux/Ubuntu
└── README.md
```

---

## The Four Forces

The DES score is computed from four market forces:

| Force | Weight | Description |
|-------|--------|-------------|
| Momentum Ratio | 30% | Buy/sell directional force |
| Volume Pressure | 25% | Volume weighted to buy side |
| Volatility (inverse) | 25% | Stability = closer to equilibrium |
| Mean Reversion Pull | 20% | Distance from moving average |

---

## Token: $DLI

**Total supply:** 21,000,000 $DLI (capped)  
**Mining model:** Proof of Use (PoU)  
**Deployment target:** Solana (Phase 3)

See [docs/WHITEPAPER.md](docs/WHITEPAPER.md) for full token details.

---

## Roadmap

- [x] Phase 1: Open-source analyzer app
- [ ] Phase 2: Community + whitepaper v2
- [ ] Phase 3: $DLI token on Solana
- [ ] Phase 4: DLI wallet + API

---

## Contributing

This is an open project. PRs welcome.  
Core principle: keep it **simple, universal, and grounded in Dynamic Equilibrium theory**.

---

## License

MIT — free to use, fork, and build on.

---

*Built with Dynamic Equilibrium theory · Dinalibrium v1.0*
