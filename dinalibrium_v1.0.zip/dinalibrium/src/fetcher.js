/**
 * Dinalibrium Data Fetcher v1.0
 * Fetches OHLCV data from CoinGecko (free, no API key needed)
 * Falls back to mock data if API unavailable
 */

const DLI_FETCHER = (() => {

  const COINGECKO_BASE = 'https://api.coingecko.com/api/v3';

  // Map of friendly names → CoinGecko IDs
  const ASSET_MAP = {
    'BTC':  { id: 'bitcoin',        name: 'Bitcoin',        type: 'crypto' },
    'ETH':  { id: 'ethereum',       name: 'Ethereum',       type: 'crypto' },
    'BNB':  { id: 'binancecoin',    name: 'BNB',            type: 'crypto' },
    'SOL':  { id: 'solana',         name: 'Solana',         type: 'crypto' },
    'XRP':  { id: 'ripple',         name: 'XRP',            type: 'crypto' },
    'ADA':  { id: 'cardano',        name: 'Cardano',        type: 'crypto' },
    'DOGE': { id: 'dogecoin',       name: 'Dogecoin',       type: 'crypto' },
    'AVAX': { id: 'avalanche-2',    name: 'Avalanche',      type: 'crypto' },
    'MATIC':{ id: 'matic-network',  name: 'Polygon',        type: 'crypto' },
    'LINK': { id: 'chainlink',      name: 'Chainlink',      type: 'crypto' },
    'DOT':  { id: 'polkadot',       name: 'Polkadot',       type: 'crypto' },
    'LTC':  { id: 'litecoin',       name: 'Litecoin',       type: 'crypto' },
    'ATOM': { id: 'cosmos',         name: 'Cosmos',         type: 'crypto' },
    'UNI':  { id: 'uniswap',        name: 'Uniswap',        type: 'crypto' },
    'TON':  { id: 'the-open-network', name: 'TON',          type: 'crypto' },
  };

  const DAYS_MAP = { '1D': 30, '1W': 90, '1M': 365 };

  /**
   * Fetch OHLCV from CoinGecko
   * Uses market_chart endpoint (no API key needed)
   */
  async function fetchCryptoOHLCV(ticker, timeframe = '1D') {
    const asset = ASSET_MAP[ticker.toUpperCase()];
    if (!asset) throw new Error(`Asset ${ticker} not found. Available: ${Object.keys(ASSET_MAP).join(', ')}`);

    const days = DAYS_MAP[timeframe] || 30;
    const url = `${COINGECKO_BASE}/coins/${asset.id}/market_chart?vs_currency=usd&days=${days}&interval=daily`;

    const resp = await fetch(url);
    if (!resp.ok) {
      // Rate limited or offline — throw to trigger fallback
      throw new Error(`CoinGecko API error: ${resp.status}`);
    }

    const json = await resp.json();

    // CoinGecko returns [ [timestamp, value], ... ]
    const closes  = json.prices.map(p => p[1]);
    const volumes = json.total_volumes.map(v => v[1]);
    const dates   = json.prices.map(p => new Date(p[0]).toISOString().split('T')[0]);

    return {
      symbol: ticker.toUpperCase(),
      name: asset.name,
      closes,
      volumes,
      dates,
      currency: 'USD',
      source: 'CoinGecko',
      currentPrice: closes[closes.length - 1],
      priceChange24h: closes.length >= 2
        ? (((closes[closes.length - 1] - closes[closes.length - 2]) / closes[closes.length - 2]) * 100).toFixed(2)
        : 0
    };
  }

  /**
   * Fetch with automatic mock fallback
   */
  async function fetchAsset(ticker, timeframe = '1D', forceMock = false) {
    if (forceMock) {
      return generateMockAsset(ticker, timeframe);
    }

    try {
      return await fetchCryptoOHLCV(ticker, timeframe);
    } catch (err) {
      console.warn(`[DLI Fetcher] API failed for ${ticker}: ${err.message}. Using mock data.`);
      return generateMockAsset(ticker, timeframe);
    }
  }

  /**
   * Generate realistic mock data for testing
   */
  function generateMockAsset(ticker, timeframe = '1D') {
    const basePrices = {
      BTC: 65000, ETH: 3400, BNB: 580, SOL: 145, XRP: 0.52,
      ADA: 0.44, DOGE: 0.16, AVAX: 38, MATIC: 0.72, LINK: 18,
      DOT: 7.2, LTC: 82, ATOM: 8.5, UNI: 9.1, TON: 5.8,
      DEFAULT: 100
    };
    const base = basePrices[ticker.toUpperCase()] || basePrices.DEFAULT;
    const periods = DAYS_MAP[timeframe] || 30;
    const closes = [], volumes = [], dates = [];
    let price = base * (0.85 + Math.random() * 0.3);
    const now = Date.now();

    for (let i = periods; i >= 0; i--) {
      const change = (Math.random() - 0.48) * 0.035;
      price = Math.max(0.0001, price * (1 + change));
      closes.push(parseFloat(price.toFixed(6)));
      volumes.push(Math.floor(Math.random() * 5e8 + 1e7));
      dates.push(new Date(now - i * 86400000).toISOString().split('T')[0]);
    }

    return {
      symbol: ticker.toUpperCase(),
      name: ticker.toUpperCase(),
      closes, volumes, dates,
      currency: 'USD',
      source: 'Mock (API unavailable)',
      currentPrice: parseFloat(price.toFixed(6)),
      priceChange24h: (((closes[closes.length-1] - closes[closes.length-2]) / closes[closes.length-2]) * 100).toFixed(2),
      isMock: true
    };
  }

  function getAvailableAssets() {
    return Object.entries(ASSET_MAP).map(([ticker, info]) => ({
      ticker,
      name: info.name,
      type: info.type
    }));
  }

  return { fetchAsset, getAvailableAssets, ASSET_MAP, generateMockAsset };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = DLI_FETCHER;
}
