/**
 * Dinalibrium DES Engine v1.0
 * Core Dynamic Equilibrium Score calculation module
 * 
 * Formula:
 * DES = 0.30*Momentum + 0.25*VolumePressure + 0.25*(1-VolatilityZ) + 0.20*MeanReversion
 * All components normalized to [0, 100]
 */

const DES_ENGINE = (() => {

  // ─── Config ─────────────────────────────────────────────────────────────
  const WEIGHTS = { momentum: 0.30, volume: 0.25, volatility: 0.25, meanReversion: 0.20 };
  const EQ_ZONE = { low: 42, high: 58 };

  // ─── Utility ─────────────────────────────────────────────────────────────
  function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }

  function mean(arr) {
    return arr.reduce((a, b) => a + b, 0) / arr.length;
  }

  function stddev(arr) {
    const m = mean(arr);
    return Math.sqrt(arr.reduce((s, v) => s + (v - m) ** 2, 0) / arr.length);
  }

  // ─── Component Calculators ───────────────────────────────────────────────

  /**
   * Momentum Score: measures ratio of upward vs downward price movement
   * Uses Rate of Change (ROC) over recent candles
   * Returns 0–100 (50 = neutral)
   */
  function calcMomentum(closes) {
    if (closes.length < 2) return 50;
    const n = Math.min(closes.length, 14);
    const recent = closes.slice(-n);
    let gains = 0, losses = 0;
    for (let i = 1; i < recent.length; i++) {
      const d = recent[i] - recent[i - 1];
      if (d > 0) gains += d;
      else losses += Math.abs(d);
    }
    if (losses === 0) return 100;
    if (gains === 0) return 0;
    const rs = gains / losses;
    // RSI-style normalization
    const rsi = 100 - (100 / (1 + rs));
    return parseFloat(rsi.toFixed(2));
  }

  /**
   * Volume Pressure Score: measures directional volume bias
   * Approximated from price-volume relationship when tick data unavailable
   * Returns 0–100 (50 = neutral, 100 = all buy pressure)
   */
  function calcVolumePressure(closes, volumes) {
    if (!volumes || volumes.length < 2) return 50;
    const n = Math.min(closes.length, volumes.length, 10);
    const rc = closes.slice(-n);
    const rv = volumes.slice(-n);
    let buyVol = 0, sellVol = 0;
    for (let i = 1; i < rc.length; i++) {
      const vol = rv[i] || 0;
      if (rc[i] > rc[i - 1]) buyVol += vol;
      else if (rc[i] < rc[i - 1]) sellVol += vol;
      else { buyVol += vol / 2; sellVol += vol / 2; }
    }
    const total = buyVol + sellVol;
    if (total === 0) return 50;
    return parseFloat(((buyVol / total) * 100).toFixed(2));
  }

  /**
   * Volatility Score (inverted): low volatility = high score
   * Uses Z-score of recent volatility vs historical volatility
   * Returns 0–100 (100 = very stable, 0 = extremely volatile)
   */
  function calcVolatilityScore(closes) {
    if (closes.length < 5) return 50;
    // Daily returns
    const returns = [];
    for (let i = 1; i < closes.length; i++) {
      returns.push((closes[i] - closes[i - 1]) / closes[i - 1]);
    }
    const recentVol = stddev(returns.slice(-7)) || 0.001;
    const histVol = stddev(returns) || 0.001;
    const zScore = clamp((recentVol - histVol) / histVol, -3, 3);
    // Convert: high z (more volatile than history) → lower score
    const score = clamp(((3 - zScore) / 6) * 100, 0, 100);
    return parseFloat(score.toFixed(2));
  }

  /**
   * Mean Reversion Pull: measures how far price is from its moving average
   * and the strength of pull back toward it
   * Returns 0–100 (50 = at mean, extremes = far from mean with strong pull)
   */
  function calcMeanReversion(closes) {
    if (closes.length < 5) return 50;
    const ma20 = mean(closes.slice(-20));
    const currentPrice = closes[closes.length - 1];
    const deviation = (currentPrice - ma20) / ma20;
    // Far below mean = high score (strong upward pull expected)
    // Far above mean = low score (strong downward pull expected)
    // At mean = 50
    const score = clamp(50 - (deviation * 200), 0, 100);
    return parseFloat(score.toFixed(2));
  }

  // ─── Main DES Calculator ─────────────────────────────────────────────────

  /**
   * Calculate full DES from OHLCV data
   * @param {Object} data - { closes: [], volumes: [], symbol: '', timeframe: '' }
   * @returns {Object} Full DES result with components, zone, and diagnosis
   */
  function calculate(data) {
    const { closes = [], volumes = [], symbol = 'ASSET', timeframe = '1D' } = data;

    if (closes.length < 5) {
      return { error: 'Insufficient data — minimum 5 candles required' };
    }

    // Calculate components
    const momentum  = calcMomentum(closes);
    const volume    = calcVolumePressure(closes, volumes);
    const volScore  = calcVolatilityScore(closes);
    const meanRev   = calcMeanReversion(closes);

    // Weighted DES
    const des = parseFloat((
      WEIGHTS.momentum     * momentum +
      WEIGHTS.volume       * volume   +
      WEIGHTS.volatility   * volScore +
      WEIGHTS.meanReversion * meanRev
    ).toFixed(2));

    // Zone diagnosis
    const zone = diagnose(des, { momentum, volume, volatility: volScore, meanReversion: meanRev });

    return {
      symbol,
      timeframe,
      des,
      components: { momentum, volume, volatility: volScore, meanReversion: meanRev },
      zone,
      timestamp: new Date().toISOString(),
      dataPoints: closes.length
    };
  }

  /**
   * Diagnose the DES score and produce actionable output
   */
  function diagnose(des, components) {
    let label, status, action, color, force;

    if (des < 20) {
      label = 'Extreme Oversold'; status = 'danger-low';
      action = 'BOOST KUAT — Tekanan jual ekstrem'; color = '#E24B4A'; force = 'Jual ekstrem';
    } else if (des < 42) {
      label = 'Under-Equilibrium'; status = 'warning-low';
      action = 'BOOST — Akumulasi bertahap'; color = '#EF9F27'; force = 'Jual dominan';
    } else if (des <= 58) {
      label = '⚖ Dinalibrium'; status = 'equilibrium';
      action = 'MAINTAIN — Kondisi seimbang'; color = '#1D9E75'; force = 'Seimbang';
    } else if (des <= 80) {
      label = 'Over-Equilibrium'; status = 'warning-high';
      action = 'STABILIZE — Kurangi eksposur'; color = '#EF9F27'; force = 'Beli dominan';
    } else {
      label = 'Extreme Overbought'; status = 'danger-high';
      action = 'REDUCE — Keluar sebagian'; color = '#E24B4A'; force = 'Beli ekstrem';
    }

    // Component-specific suggestions
    const suggestions = [];
    if (components.momentum < 35)    suggestions.push('Momentum lemah — tunggu pembalikan');
    if (components.momentum > 70)    suggestions.push('Momentum tinggi — waspadai exhaustion');
    if (components.volume < 35)      suggestions.push('Volume beli rendah — konfirmasi lemah');
    if (components.volume > 75)      suggestions.push('Volume beli tinggi — momentum kuat');
    if (components.volatility < 30)  suggestions.push('Volatilitas ekstrem — risiko tinggi');
    if (components.meanReversion < 30) suggestions.push('Jauh di atas MA — pullback berisiko');
    if (components.meanReversion > 70) suggestions.push('Jauh di bawah MA — reversal potential');

    return { label, status, action, color, force, suggestions, inEquilibrium: des >= 42 && des <= 58 };
  }

  // ─── Mock Data Generator (for testing without API) ───────────────────────

  function generateMockOHLCV(basePrice = 100, periods = 30, volatility = 0.02) {
    const closes = [], volumes = [], dates = [];
    let price = basePrice;
    const now = Date.now();

    for (let i = periods; i >= 0; i--) {
      const change = (Math.random() - 0.48) * volatility;
      price = Math.max(0.01, price * (1 + change));
      closes.push(parseFloat(price.toFixed(4)));
      volumes.push(Math.floor(Math.random() * 1000000 + 100000));
      const d = new Date(now - i * 86400000);
      dates.push(d.toISOString().split('T')[0]);
    }
    return { closes, volumes, dates };
  }

  // ─── Public API ──────────────────────────────────────────────────────────
  return {
    calculate,
    diagnose,
    generateMockOHLCV,
    EQ_ZONE,
    WEIGHTS,
    // Expose internals for testing
    _calcMomentum: calcMomentum,
    _calcVolumePressure: calcVolumePressure,
    _calcVolatilityScore: calcVolatilityScore,
    _calcMeanReversion: calcMeanReversion,
  };
})();

// CommonJS export (Node.js / Termux testing)
if (typeof module !== 'undefined' && module.exports) {
  module.exports = DES_ENGINE;
}
